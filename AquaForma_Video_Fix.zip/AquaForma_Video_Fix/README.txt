AquaForma video embed correction

This patch contains only index.html. The video gallery was already included in the previous site update; this replaces the second unverified YouTube embed with a video found in YouTube search results. The first embed remains the garden waterfall project video.

Apply it to GitHub:
1. Extract this ZIP.
2. Open https://github.com/MechAn1cq/aquaforma-website.
3. Click Add file -> Upload files.
4. Upload index.html from this folder to the repository root.
5. If GitHub asks to replace the existing index.html, confirm replacement.
6. Commit directly to main.
7. Wait for Render's aquaforma-site deploy to show Live, then open the site and press Ctrl+F5.

No other files need to be changed for this correction.
